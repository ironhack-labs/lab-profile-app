import React from 'react';

function NotFound() {
  return (
    <div>
      <h2>Not found</h2>
    </div>
  );
}

export default NotFound;
